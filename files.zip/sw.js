var CACHE='ponto-v1';
self.addEventListener('install',function(e){self.skipWaiting();});
self.addEventListener('activate',function(e){self.clients.claim();});
self.addEventListener('fetch',function(e){
  if(e.request.url.includes('anthropic.com')||e.request.url.includes('googleapis.com'))return;
  e.respondWith(caches.open(CACHE).then(function(c){
    return c.match(e.request).then(function(r){
      return r||fetch(e.request).then(function(res){c.put(e.request,res.clone());return res;});
    });
  }));
});